package com.jmdc.mars.robots;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RobotsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RobotsApplication.class, args);
	}

}
